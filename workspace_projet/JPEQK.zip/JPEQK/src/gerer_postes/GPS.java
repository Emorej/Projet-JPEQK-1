package gerer_postes;

public class GPS {

}
